select * from libros;

create or replace  PROCEDURE nuevolibro(editorial in libros.editorial%TYPE)
is 

begin 
select titulo,autor,editorial,precio from libros;

end;