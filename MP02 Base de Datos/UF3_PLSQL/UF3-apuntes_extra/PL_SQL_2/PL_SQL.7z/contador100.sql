select * from libros;

create or replace  PROCEDURE cierto(editorial in libros.editorial%TYPE)
is 

begin 
num2 := num1 + (num*0.1)

end;