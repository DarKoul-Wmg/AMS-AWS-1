
public interface FillTank {
	public void fill();
}
