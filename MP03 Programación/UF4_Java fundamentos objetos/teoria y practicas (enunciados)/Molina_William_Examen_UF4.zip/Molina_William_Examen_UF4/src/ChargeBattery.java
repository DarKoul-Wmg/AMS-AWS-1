
public interface ChargeBattery {
	public void charge();
}
