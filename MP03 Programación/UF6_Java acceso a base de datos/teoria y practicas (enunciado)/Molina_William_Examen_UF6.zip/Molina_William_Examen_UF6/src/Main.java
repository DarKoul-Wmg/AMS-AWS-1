import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Scanner;



public class Main {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String urlDatos = "jdbc:mysql://localhost/ChessClub?serverTimezone=UTC&autoReconnect=true&useSSL=false";
		String usuario = "root";
		String pass = "P@ssw0rd";
		Scanner scanner = new Scanner(System.in);
		try {
			
			//a Conexion base de datos ChessClub:
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection conn = DriverManager.getConnection(urlDatos,usuario,pass);
			System.out.println("Conexion creada correctamente.");
			
			
			Statement stmnt = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);//compatible con la bbdd
			
			
			//b Ingresar registros de Countries:
	        			
			System.out.println("\n==========================================");
			System.out.println("Insert de Paises");
			System.out.println("==========================================");

			String insert = "INSERT INTO countries(id, countryName) VALUES(177, 'Finland')";
			System.out.println(insert);
			stmnt.executeUpdate(insert);
			insert = "INSERT INTO countries(id, countryName) VALUES(241, 'Portugal')";
			System.out.println(insert);
			stmnt.executeUpdate(insert);
			insert = "INSERT INTO countries(id, countryName) VALUES(352, 'United Kingdom')";
			System.out.println(insert);
			stmnt.executeUpdate(insert);
			insert = "INSERT INTO countries(id, countryName) VALUES(128, 'Spain')";
			System.out.println(insert);
			stmnt.executeUpdate(insert);
			insert = "INSERT INTO countries(id, countryName) VALUES(265, 'France')";
			System.out.println(insert);
			stmnt.executeUpdate(insert);
			
			//c ArrayList de players e Insert de jugadores
			ArrayList<Player> players = new ArrayList<Player>();
			players.add(new Player(125, "22222222A", "Sonia", 2300, 177));
			players.add(new Player(138, "33333333B", "Alba", 47000, 352));
			players.add(new Player(152, "44444444R", "Amaya", 7500, 128));
			players.add(new Player(241, "55555555T", "Nando", 14000, 265));
			players.add(new Player(312, "66666666S", "Andrea", 25000, 241));
			
			System.out.println("\n==========================================");
			System.out.println("Insert de Players");
			System.out.println("==========================================");
			for(Player p : players) {				
					String update = "INSERT INTO players ( id, dni, playerName, points, idCountry) VALUES ("+
							p.getId()+", \""+p.getDni()+" \" , \""+p.getName()+"\","+p.getPoints()+", "+ p.getIdPais()+")";
					
				System.out.println(update);
				stmnt.executeUpdate(update);	
			}
			
		//d mostrar todos los registros de players:
		
			String query = "SELECT * from players"; 
			ResultSet rs = stmnt.executeQuery(query);
			ResultSetMetaData rsmd = rs.getMetaData();
			while (rs.next())
			{
				System.out.println(rsmd.getColumnName(1) + " := " + rs.getInt(1) + ", "
				+ rsmd.getColumnName(2) + " = " + rs.getString(2) + ", "
				+ rsmd.getColumnName(3) + " = " + rs.getString(3)+ ", "
				+ rsmd.getColumnName(4) + " = " + rs.getInt(4)+ ", "
				+ rsmd.getColumnName(5) + " = " + rs.getInt(5));
			}
			
		//e Nom de los players con ID > 130:
			System.out.println("\n==========================================");
			System.out.println("ID > 130");
			System.out.println("==========================================");
			
			rs.absolute(0); //Nos posicionamos al principio
			while (rs.next())
			{
				if(rs.getInt(1) > 130) //filtro
				{
					System.out.println(rsmd.getColumnName(1) + " := " + rs.getInt(1) + ", "
							+ rsmd.getColumnName(2) + " = " + rs.getString(2) + ", "
							+ rsmd.getColumnName(3) + " = " + rs.getString(3)+ ", "
							+ rsmd.getColumnName(4) + " = " + rs.getInt(4)+ ", "
							+ rsmd.getColumnName(5) + " = " + rs.getInt(5));
				}
				
			}
			
		
			
		
			
			
			
		//f Resetear arrayList, anadir 2 players e insterar con Prepared Statement 
			
			players.clear();
			
			players.add(new Player(666, "77777777C", "Willy", 66666, 128));
			players.add(new Player(512, "88888888D", "Ivan", 70512, 128));
			
			
			
			String update = "INSERT INTO players(id, dni, playerName, points, idCountry) VALUES (?,?,?,?,?)";
			PreparedStatement ps = conn.prepareStatement(update);
						
			for (Player p : players) {
				ps.setInt(1, p.getId());
				ps.setString(2, p.getDni());
				ps.setString(3, p.getName());
				ps.setInt(4, p.getPoints());
				ps.setInt(5, p.getIdPais());
				ps.executeUpdate();
				
				//rs.insertRow();
			}
			
			
			System.out.println(">> Insert realizado correctamente");
			
			
		//g Mostrar todos los juagdores con mas de 10000 points y de Portugal con PreparedStatement
		
			System.out.println("\n==========================================");
			System.out.println("Puntos de jugadores de Portugal > 10000");
			System.out.println("==========================================");
			
			query = "SELECT * FROM players WHERE points > ? AND idCountry = ?";
			ps = conn.prepareStatement(query);
			ps.setInt(1, 10000);
			ps.setInt(2, 241);
			
			rs = ps.executeQuery();
			
			while (rs.next()) {
				System.out.println(rsmd.getColumnName(1) + " := " + rs.getInt(1) + ", "
						+ rsmd.getColumnName(2) + " = " + rs.getString(2) + ", "
						+ rsmd.getColumnName(3) + " = " + rs.getString(3)+ ", "
						+ rsmd.getColumnName(4) + " = " + rs.getInt(4)+ ", "
						+ rsmd.getColumnName(5) + " = " + rs.getInt(5));
			}
			
		//h  Insert en el resultset anterior y que se refleje en la base de datos:
			
                   			
			try {
					
				DatabaseMetaData metaData = conn.getMetaData();
				
				boolean estaSoportado = metaData.supportsResultSetConcurrency(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_UPDATABLE);
				if (estaSoportado) {
					System.out.println("Esta base de datos soporta este tipo de result set");
				}else {
					System.out.println("Esta base de datos NO soporta este tipo de result set");
				}
						
				//primero ponemos el apuntador en el ultimo registro
				rs.moveToInsertRow();					 
				     
				rs.updateInt(1, 320);
				rs.updateString(2, "Antonio");
				rs.updateString(3, "99999999P");
				rs.updateInt(4, 12000);
				rs.updateInt(5, 241);
				rs.insertRow();
				
			} catch (SQLException e) {
				System.out.println("Error al insertar registro:");
				e.printStackTrace();
			}
//            rs.updateInt(1, 320);
//            rs.updateString(2, "Antonio");
//            rs.updateString(3, "99999999P");
//            rs.updateInt(4, 12000);
//            rs.updateInt(5, 241);
           
			
            
            System.out.println("\n>> Insert realizado correctamente");
            
           
			
		
        //i  Modificar todos los jugadores del ResultSet con más de 10000 y reestablecer sus puntos a 10000
            
            
			
			System.out.println("==========================================");
			System.out.println("Actualizar puntuacion players > 10000");
			System.out.println("==========================================");
			
			query = "UPDATE players SET points = 10000 WHERE points > ?;";
			ps = conn.prepareStatement(query);
			ps.setInt(1, 10000);
			ps.executeUpdate();
			System.out.println(">> Update realizado correctamente");
			
			System.out.println("Players con puntuaciones a 10000:");
			
			query = "SELECT * FROM players WHERE points = 10000";
			ps = conn.prepareStatement(query);
			rs = ps.executeQuery();
			while (rs.next()) {
				System.out.println(rsmd.getColumnName(1) + " := " + rs.getInt(1) + ", "
						+ rsmd.getColumnName(2) + " = " + rs.getString(2) + ", "
						+ rsmd.getColumnName(3) + " = " + rs.getString(3)+ ", "
						+ rsmd.getColumnName(4) + " = " + rs.getInt(4)+ ", "
						+ rsmd.getColumnName(5) + " = " + rs.getInt(5));
			}
			
            conn.close();
            System.out.println("\nConexion cerrada correctamente...");
		} catch (ClassNotFoundException e) {
			System.out.println("Error! Class Not Found:");
			e.printStackTrace();
		} catch (SQLException e) {
			System.out.println("Error! SQL Exception:");
			e.printStackTrace();
		}

	}

}
